/******************************************************************************
 *
 * File:        manymovieEvents.h
 *
 * Description: External interface to manymovieEvents.c. Handles X and
 *              Movie events for manymovie. 
 *
 *****************************************************************************/

extern void handleEvents( void );
