/****************************************************************************
 *
 * File:	createmovieResize.h
 *
 * Description:	Public declarations for createmovieResize.c++
 *
 ****************************************************************************/

void resizeImageFrame( int oldWidth, int oldHeight, void* oldBuffer,
                         int newWidth, int newHeight, void* newBuffer );
