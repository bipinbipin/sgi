/*****************************************************************************
 *
 * File:	createmovieInit.h
 *
 * Description:	External declarations for createmovieInit.c++.
 *
 *****************************************************************************/

#include <dmedia/moviefile.h>

extern void initMovie( MVid *theMovie );
