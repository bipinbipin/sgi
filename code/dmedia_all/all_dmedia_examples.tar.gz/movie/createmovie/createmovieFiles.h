/*****************************************************************************
 *
 * File:	createmovieFiles.h
 *
 * Description:	External declarations for createmovieFiles.c++.
 *
 *****************************************************************************/

#include <dmedia/moviefile.h>

extern void putFilesInMovie( MVid theMovie );
