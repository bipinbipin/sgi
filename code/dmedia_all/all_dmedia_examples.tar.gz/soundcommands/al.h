/*
 * function declarations for audio stuff
 */
double GetAudioHardwareRate(int);

int AudioOutputHardwareInUse(int);
